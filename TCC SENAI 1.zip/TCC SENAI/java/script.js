var Invest = 1000;

    function mais() {
        Invest += 250;
        Atualizar();
    }

    function menos() {
        if (Invest >= 250) {
            Invest -= 250;
            Atualizar();
        }
    }

    function Atualizar() {
        document.getElementById("Invest").innerHTML = "R$ " + Invest.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    }

    var Deposit = 1000;

    function mais2() {
        Deposit += 250;
        Atualizar2();
    }

    function menos2() {
        if (Deposit >= 250) {
            Deposit -= 250;
            Atualizar2();
        }
    }

    function Atualizar2() {
        document.getElementById("Deposit").innerHTML = "R$ " + Deposit.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    }

    function Atualizar3(numero) {
        var textoMeses = (numero == 1) ? "mês" : "meses";
        var textoMeses2 = (numero == 0) ? "mês" : "meses";
        document.getElementById("mes01").innerText = numero + " " + textoMeses;
    }