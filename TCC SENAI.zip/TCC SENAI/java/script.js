//Para começar, qual valor você gostaria de investir? (start)
var valorInvestido = 1000;

    function aumentarInvestimento() {
        valorInvestido += 250;
        atualizarValorInvestido();
    }

    function diminuirInvestimento() {
        if (valorInvestido >= 250) {
            valorInvestido -= 250;
            atualizarValorInvestido();
        }
    }

    function atualizarValorInvestido() {
        document.getElementById("valorInvestido").innerHTML = "R$ " + valorInvestido.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    }
//Para começar, qual valor você gostaria de investir? (end)

//E por mês, quanto gostaria de depositar? (start)
    var valorDepositado = 1000;

    function aumentarInvestimento2() {
        valorDepositado += 250;
        atualizarValorInvestido2();
    }

    function diminuirInvestimento2() {
        if (valorDepositado >= 250) {
            valorDepositado -= 250;
            atualizarValorInvestido2();
        }
    }

    function atualizarValorInvestido2() {
        document.getElementById("valorDepositado").innerHTML = "R$ " + valorDepositado.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    }
//E por mês, quanto gostaria de depositar? (end)

//Quanto tempo deixaria seu dinheiro investido? (start)
    function atualizarNumeroExibido(numero) {
        // Atualizar o conteúdo do elemento com o id "numeroExibido" com o número digitado e a string "mês" ou "meses"
        var textoMeses = (numero == 1) ? "mês" : "meses";
        var textoMeses2 = (numero == 0) ? "mês" : "meses";
        document.getElementById("numeroExibido").innerText = numero + " " + textoMeses;
    }
//Quanto tempo deixaria seu dinheiro investido? (end )